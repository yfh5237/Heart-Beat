import matplotlib.pyplot as plt
import numpy as np
import time
import time, random
import math
import serial
from collections import deque
from scipy import signal

b = [1/4, -2/4, 1/4]
w, h = signal.freqz(b)

plt.figure(figsize=[10,5])
plt.subplot(121)
plt.plot(w, abs(h))
plt.title('Frequency_response')

plt.subplot(122)
plt.plot(np.angle(h))
plt.xlabel(r'$\hat\omega$  (radian)')
plt.title('The phase spectrum')

z = np.roots([1/4, -2/4, 1/4])
p = np.roots(0)
plt.figure(figsize=(8,8))
angle = np.linspace(-np.pi, np.pi, 50)
cirx = np.sin(angle)
ciry = np.cos(angle)
plt.plot(cirx, ciry,'k-')
plt.plot(np.real(z), np.imag(z), 'o', markersize=12)
plt.grid()

plt.xlim((-2, 2))
plt.xlabel('Real')
plt.ylim((-2, 2))
plt.ylabel('Imag')
plt.show()
